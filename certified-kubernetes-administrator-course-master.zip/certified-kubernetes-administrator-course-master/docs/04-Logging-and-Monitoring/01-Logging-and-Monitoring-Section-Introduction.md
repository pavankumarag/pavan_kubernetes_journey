# Logging and Monitoring Section Introduction
  - Take me to [Video Tutorial](https://kodekloud.com/courses/539883/lectures/9808185)
  
In this section, we will take a look at the below
- Monitor Cluster Components
- Monitor Applications
- Monitor Cluster Components Logs
- Application Logs
