# Storage in Docker

  Take me to [Storage](https://kodekloud.com/courses/certified-kubernetes-administrator-with-practice-tests/lectures/13350400)