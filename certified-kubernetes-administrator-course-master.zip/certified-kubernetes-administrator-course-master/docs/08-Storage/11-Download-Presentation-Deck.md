# Download Presentation Deck

  [Download](https://kodekloud.com/courses/certified-kubernetes-administrator-with-practice-tests/lectures/16093022)