# Using PVC in PODs

  - Take me the [Lecture](https://kodekloud.com/courses/certified-kubernetes-administrator-with-practice-tests/lectures/13154680)