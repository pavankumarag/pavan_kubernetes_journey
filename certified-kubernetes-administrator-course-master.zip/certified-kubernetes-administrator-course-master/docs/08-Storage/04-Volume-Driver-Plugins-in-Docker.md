# Volume Driver Plugins in Docker

  Take me to [Lecture](https://kodekloud.com/courses/certified-kubernetes-administrator-with-practice-tests/lectures/13350437)