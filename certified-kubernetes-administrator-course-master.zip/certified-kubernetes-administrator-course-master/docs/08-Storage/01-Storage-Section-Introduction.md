# Storage Section Introduction

  Take me to [Introduction](https://kodekloud.com/courses/certified-kubernetes-administrator-with-practice-tests/lectures/9808276)