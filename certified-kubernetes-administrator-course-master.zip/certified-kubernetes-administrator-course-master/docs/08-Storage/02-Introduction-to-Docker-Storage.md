# Introduction to Docker Storage

  Take me to [Docker Introduction](https://kodekloud.com/courses/certified-kubernetes-administrator-with-practice-tests/lectures/13350395)