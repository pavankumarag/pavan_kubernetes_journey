# Multi-Container Pods Design Patterns
  - Take me to [Tutorial](https://kodekloud.com/courses/certified-kubernetes-administrator-with-practice-tests/lectures/10589174)
  
  ![dp](../../images/dp.PNG)
  
#### K8s Reference Docs
- https://kubernetes.io/blog/2015/06/the-distributed-system-toolkit-patterns/
