# Application Lifecycle Management Section Introduction
  - Take me to [Video Tutorial](https://kodekloud.com/courses/539883/lectures/9808200)
  
In this section, we will take a look at application lifecycle management
- Rolling Updates and Rollbacks in Deployments
- Configure Applications
- Scale Applications
- Self-Healing Application

