# Practice Test Introduction

In this section, we will take a look at practice test demo.
- Take me to [Video Tutorial](https://kodekloud.com/courses/539883/lectures/9808164)

