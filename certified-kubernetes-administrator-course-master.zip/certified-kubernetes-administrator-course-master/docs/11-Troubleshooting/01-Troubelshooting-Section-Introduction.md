# Troubelshooting Section Introduction

  - Lets understand how we can troubleshoot an [Application Failure](https://kodekloud.com/courses/539883/lectures/9808360).