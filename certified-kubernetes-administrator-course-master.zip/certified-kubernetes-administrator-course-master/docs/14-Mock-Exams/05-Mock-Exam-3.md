# Mock Exam 2

  Wohooo! Level Up! 
  Take me to [Mock Exam 2](https://kodekloud.com/courses/539883/lectures/11118242)