# Mock Exams Introduction 

  Take me to [Introduction of Mock Exams](https://kodekloud.com/courses/539883/lectures/10853073)