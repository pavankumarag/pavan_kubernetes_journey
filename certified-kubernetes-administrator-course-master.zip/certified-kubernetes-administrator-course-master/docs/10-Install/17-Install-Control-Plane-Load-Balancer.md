# Install Control Plane Load Balancer

  Take me to [Lecture](https://kodekloud.com/courses/539883/lectures/9808344)