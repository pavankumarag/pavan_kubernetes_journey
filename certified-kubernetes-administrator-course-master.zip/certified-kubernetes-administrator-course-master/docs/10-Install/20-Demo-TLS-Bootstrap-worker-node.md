# Demo TLS Bootstrap worker node

  Take me to [Lecture](https://kodekloud.com/courses/539883/lectures/9808340)