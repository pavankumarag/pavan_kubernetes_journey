# Designing a Kubernetes Cluster

  Take me to [Designing](https://kodekloud.com/courses/539883/lectures/9817006)