# Install worker node components

  Take me to [Lecture](https://kodekloud.com/courses/539883/lectures/9808327)