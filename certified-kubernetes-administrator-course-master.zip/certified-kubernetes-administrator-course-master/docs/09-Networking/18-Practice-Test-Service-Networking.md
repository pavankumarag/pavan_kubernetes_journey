# Practice Test Service Networking

  Take me to [Lab](https://kodekloud.com/courses/certified-kubernetes-administrator-with-practice-tests/lectures/9816800)

  #### Solution 

  1. Check the Solution

     <details>

      ```
      172.17.0.0/16
      ```
     </details>

  2. Check the Solution

     <details>

      ```
      10.32.0.0/12
      ```
     </details>

  3. Check the Solution

     <details>

      ```
      10.96.0.0/12
      ```
     </details>

  4. Check the Solution

     <details>

      ```
      2
      ```
     </details>

  5. Check the Solution

     <details>

      ```
      iptables
      ```
     </details>

  6. Check the Solution

     <details>

      ```
      using daemonset
      ```
     </details>

