# Practice Test CNI weave

  Take me to [Lab](https://kodekloud.com/courses/539883/lectures/9816778)

  #### Solution

  1. Check the Solution

     <details>

      ``` 
      CNI
      ```
     </details>

  2. Check the Solution

     <details>

      ```
      /opt/cni/bin
      ```
     </details>

  3. Check the Solution

     <details>

      ```
      cisco
      ```
     </details>

  4. Check the Solution

     <details>

      ```   
      weave
      ```
     </details>

  5. Check the Solution

     <details>

      ```
      weave-net
      ```
     </details>

