# Practice Test Networking Weave

  Take me to [Lab](https://kodekloud.com/courses/certified-kubernetes-administrator-with-practice-tests/lectures/9816785)

  #### Solution 

  1. Check the Solution

     <details>

      ```
      4
      ```
     </details>

  2. Check the Solution

     <details>

      ```
      weave
      ```
     </details>

  3. Check the Solution

     <details>

      ```
      4
      ```
     </details>

  4. Check the Solution

     <details>

      ```
      One on every node
      ```
     </details>

  5. Check the Solution

     <details>

      ```
      weave
      ```
     </details>

  6. Check the Solution

     <details>

      ```
      10.X.X.X
      ```
     </details>

  7. Check the Solution

     <details>

      ```
      10.38.0.0
      ```
     </details>