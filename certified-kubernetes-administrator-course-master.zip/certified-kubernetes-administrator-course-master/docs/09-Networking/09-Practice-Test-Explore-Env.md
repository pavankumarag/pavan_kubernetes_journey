# Practice Test Explore Env

  Take me to [Lab](https://kodekloud.com/courses/539883/lectures/9816753)

  #### Solution

  1. Check the Solution

     <details>

      ```
       2 
      ```
     </details>

  2. Check the Solution

     <details>

      ```
      ens3
      ```
     </details>

  3. Check the Solution

     <details>

      ```
      172.17.0.31
      ```
     </details>

  4. Check the Solution

     <details>

      ```
      02:42:ac:11:00:1f
      ```
     </details>

  5. Check the Solution

     <details>

      ```
      172.17.0.32
      ```
     </details>

  6. Check the Solution

     <details>

      ```
      02:42:ac:11:00:20
      ```
     </details>

  7. Check the Solution

     <details>

      ```
      docker0
      ```
     </details>

  8. Check the Solution

     <details>

      ```
      DOWN
      ```
     </details>

  9. Check the Solution

     <details>

      ```
      172.17.0.1
      ```
     </details>

  9. Check the Solution

     <details>

      ```
      10251
      ```
     </details>

  9. Check the Solution

     <details>

      ```
      2379
      ```
     </details>

  9. Check the Solution

     <details>

      ```
      Ok
      ```
     </details>