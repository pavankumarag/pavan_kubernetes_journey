# Practice Test Deploy Networking Solution

  Take me to [Lab](https://kodekloud.com/courses/certified-kubernetes-administrator-with-practice-tests/lectures/9892583)

  #### Solution

  1. Check the Solution

     <details>

      ```
      Not Running
      ```
     </details>

  2. Check the Solution

     <details>

      ```
      No Network Configured
      ```
     </details>

  3. Check the Solution

     <details>

      ```
      Click [here](https://www.weave.works/docs/net/latest/kubernetes/kube-addon/)

      OR Execute below command

      kubectl apply -f "https://cloud.weave.works/k8s/net?k8s-version=$(kubectl version | base64 | tr -d '\n')"
      ```
     </details>