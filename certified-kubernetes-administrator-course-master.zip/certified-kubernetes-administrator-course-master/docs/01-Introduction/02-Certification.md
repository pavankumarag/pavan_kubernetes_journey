# Certification

  - Take me to [Video Tutorial](https://kodekloud.com/courses/539883/lectures/9814246)
  
## Certification Details

   - **`Certified Kubernetes Administrator`**: https://www.cncf.io/certification/cka/

   - **`Exam Curriculum (Topics)`**: https://github.com/cncf/curriculum

   - **`Candidate Handbook`**: https://www.cncf.io/certification/candidate-handbook

   - **`Exam Tips`**: http://training.linuxfoundation.org/go//Important-Tips-CKA-CKAD

#### Use the code - KUBERNETES15 - while registering for the CKA or CKAD exams at Linux Foundation to get a 15% discount.

