# Cluster Maintenance Section Introduction
  - Take me to [Video Tutorial](https://kodekloud.com/courses/539883/lectures/9808231)
  
In this section, we will take a look at cluster maintenance
- Cluster Upgrade Process
- Operating System Upgrades
- Backup and Restore Methodologies
