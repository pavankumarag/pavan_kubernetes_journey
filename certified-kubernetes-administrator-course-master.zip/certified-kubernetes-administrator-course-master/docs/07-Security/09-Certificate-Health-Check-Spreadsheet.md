# Certificate Health-Check Spreadsheet
  - Take me to [Spreedsheet](https://kodekloud.com/courses/539883/lectures/11777973)
  
