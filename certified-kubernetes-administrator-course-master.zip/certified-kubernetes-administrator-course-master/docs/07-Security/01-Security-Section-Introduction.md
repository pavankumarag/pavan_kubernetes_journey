# Security Section Introduction
  - Take me to [Video Tutorial](https://kodekloud.com/courses/539883/lectures/9808249)

In this section, we will take a look at security section introduction
- Kubernetes Security Primitives
- Authentication
- TLS certificates for cluster components
- Secure Persistent key-value store
- Authorization
- Images Security
- Security Contexts
- Network Policies   
