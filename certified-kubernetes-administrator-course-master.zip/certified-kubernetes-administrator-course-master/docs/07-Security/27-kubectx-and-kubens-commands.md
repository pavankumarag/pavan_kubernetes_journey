# kubectx and kubens commands
  - Take me to [Tutorial](https://kodekloud.com/courses/certified-kubernetes-administrator-with-practice-tests/lectures/13056451)
