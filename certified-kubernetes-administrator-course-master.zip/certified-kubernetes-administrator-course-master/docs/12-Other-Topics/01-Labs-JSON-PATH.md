# Labs JSON PATH

  - I want to learn Json, Take me to [JSON PATH](https://kodekloud.com/p/json-path-quiz)